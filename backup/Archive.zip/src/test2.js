import DocRegenExtend from './test.js';

export default class DocRegenExtend2 extends DocRegenExtend
{
   destroy()
   {
      super.destroy();
   }
}
