import WatcherDocRegenerator from './WatcherDocRegenerator.js';

export default class DocRegenExtend extends WatcherDocRegenerator
{
   destroy()
   {
      super.destroy();
   }
}
