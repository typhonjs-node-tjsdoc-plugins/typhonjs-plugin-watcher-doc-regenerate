import Testing1 from './Testing1.js';

export default class Testing2 extends Testing1
{
   static TESTTEST() {};
}
