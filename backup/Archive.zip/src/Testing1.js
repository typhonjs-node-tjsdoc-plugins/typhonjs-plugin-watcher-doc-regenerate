/**
 * Test
 */
export default class Testing1
{
   /**
    * Create
    */
   static create()
   {
      console.log('!! Test1 - create - TESTTEST: ' + (typeof this.TESTTEST));
   }
}
