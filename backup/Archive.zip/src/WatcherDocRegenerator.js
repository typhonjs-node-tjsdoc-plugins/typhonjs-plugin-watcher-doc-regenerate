/**
 * Provides file watching doc regeneration control flow for TJSDoc during the `onComplete` callback utilizing.
 */
export class WatcherDocRegenerator
{
   /**
    * Instantiate DocRegenerator then initialize it.
    *
    * @param {PluginEvent} ev - The `onComplete` plugin event.
    */
   constructor(ev)
   {
      /**
       * The plugin event proxy.
       * @type {EventProxy}
       */
      this.eventbus = ev.eventbus;

      /**
       * A local event proxy for DocRegenerator.
       * @type {EventProxy}
       */
      this.eventProxy = ev.eventbus.createEventProxy();

      /**
       * The target project TJSDocConfig object.
       * @type {TJSDocConfig}
       */
      this.mainConfig = ev.data.mainConfig;

      /**
       * The plugin options.
       * @type {object}
       */
      this.pluginOptions = ev.pluginOptions;

      this.initialize();
   }

   /**
    * Unregisters any local event bindings on TJSDoc regeneration of all docs.
    */
   destroy()
   {
      this.eventProxy.off();
   }

   fileAdd(file)
   {
      try
      {
         if (!file.options.silent)
         {
            this.eventbus.trigger('tjsdoc:system:watcher:terminal:log',
             `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} added: ${file.path}`);
         }
      }
      catch (err)
      {
         this.eventbus.trigger('log:warn:time',
          `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} adding failed: ${file.path}`, err);
      }
   }

   async fileChange(file)
   {
      try
      {
         if (!file.options.silent)
         {
            this.eventbus.trigger('tjsdoc:system:watcher:terminal:log',
             `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} changed: ${file.path}`);

            if (file.options.dependent) { this.logDependencies(file.path); }
         }

         // Synthesize silent from a combination of watcher options silent & verbose. Any logging from other systems
         // during the regeneration and republishing process will only occur if watcher options are not silent and
         // verbose.
         const silent = (file.options.silent | !file.options.verbose) === 1;

         let filePath = [file.path];

         let sourceCoverage = false;

         switch (file.type)
         {
            case 'index':
               // console.log('!! tjsdoc-plugin-watcher-doc-regenerator - fileChange - index: ' + JSON.stringify(file));
               break;

            case 'manual':
               console.log('!! tjsdoc-plugin-watcher-doc-regenerator - fileChange - manual: ' + JSON.stringify(file));
               break;

            case 'source':
               filePath = this.eventbus.triggerSync('tjsdoc:system:regenerate:source:doc:data', {
                  dependent: file.options.dependent,
                  filePath: file.path,
                  silent
               });

               sourceCoverage = file.options.coverage;
               break;

            case 'test':
               filePath = this.eventbus.triggerSync('tjsdoc:system:regenerate:test:doc:data', {
                  dependent: file.options.dependent,
                  filePath: file.path,
                  silent
               });
               break;
         }

         // Invoke publisher with file path constraints which will update just the published docs that match the given
         // file path constraint.
         await this.eventbus.triggerAsync('tjsdoc:system:publisher:publish', {
            fileAction: file.action,
            filePath,
            fileType: file.type,
            incremental: true,
            minimal: file.options.minimal,
            section: file.section,
            silent
         });

         // If a source file has changed and coverage option is enabled then output the current status.
         if (sourceCoverage)
         {
            this.eventbus.trigger('tjsdoc:data:docdb:coverage:source:log',
             { filePath, includeFiles: true, includeLines: true });
         }
      }
      catch (err)
      {
         this.eventbus.trigger('log:warn:time',
          `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} changing failed: ${file.path}`, err);
      }
   }

   fileUnlink(file)
   {
      try
      {
         if (!file.options.silent)
         {
            this.eventbus.trigger('tjsdoc:system:watcher:terminal:log',
             `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} unlinked: ${file.path}`);
         }
      }
      catch (err)
      {
         this.eventbus.trigger('log:warn:time',
          `tjsdoc-plugin-watcher-doc-regenerator - ${file.type} unlinking failed: ${file.path}`, err);
      }
   }

   /**
    * Performs setup and initialization of all event bindings connecting to `tjsdoc-plugin-watcher`.
    */
   initialize()
   {
      // Setup callback for when tjsdoc-plugin-watcher detects changes.
      this.eventProxy.on('tjsdoc:system:watcher:update', this.updateDispatch, this);
   }

   /**
    * Logs any dependent files from the given file path. Any existing file doc for the file path that has resolved
    * data for `_custom_dependent_file_paths` is logged.
    *
    * @param {string}   filePath - The file path to log existing dependencies.
    */
   logDependencies(filePath)
   {
      const existingFileDoc = this.eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'ModuleFile', filePath })[0];

      if (existingFileDoc && Array.isArray(existingFileDoc._custom_dependent_file_paths))
      {
         for (const depFilePath of existingFileDoc._custom_dependent_file_paths)
         {
            this.eventbus.trigger('tjsdoc:system:watcher:terminal:log',
             `tjsdoc-plugin-watcher-doc-regenerator - dependent: ${depFilePath}`);
         }
      }
   }

   updateDispatch(file)
   {
      if (typeof file !== 'object') { this.eventbus.trigger('log:error', `'file' is not an 'object'.`); return; }

      switch (file.action)
      {
         case 'file:add':
            this.fileAdd(file);
            break;

         case 'file:change':
            this.fileChange(file);
            break;

         case 'file:unlink':
            this.fileUnlink(file);
            break;
      }
   }
}

let docRegenerator;

/**
 * Initializes DocRegenerator listening for events from `typhonjs-plugin-watcher`.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onRuntimeCompleteAsync(ev)
{
   docRegenerator = new WatcherDocRegenerator(ev);
}

/**
 * Adds `typhonjs-live-server` event bindings to start / shutdown `live-server`.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export async function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const pluginOptions = ev.pluginOptions;

   // Only load one instance of tjsdoc-plugin-watcher depending on TJSDOC_ENV mode.
   let hasPlugin = eventbus.triggerSync('plugins:has:plugin', 'tjsdoc-plugin-watcher');
   if (!hasPlugin)
   {
      const target = process.env.TJSDOC_ENV === 'development' ? '../tjsdoc-plugin-watcher/src/Watcher.js' :
       'tjsdoc-plugin-watcher';

      await eventbus.triggerAsync('plugins:add:async', { name: 'tjsdoc-plugin-watcher', target });
   }

   const liveServer = typeof pluginOptions.liveServer === 'boolean' ? pluginOptions.liveServer : true;

   // Early out if live server will not be loaded.
   if (!liveServer) { return; }

   // Only load one instance of tjsdoc-plugin-live-server depending on TJSDOC_ENV mode.
   hasPlugin = eventbus.triggerSync('plugins:has:plugin', 'tjsdoc-plugin-live-server');

   if (!hasPlugin)
   {
      // Obtain any live server options.
      const liveServerOptions = typeof pluginOptions.liveServerOptions === 'object' ?
       pluginOptions.liveServerOptions : {};

      const target = process.env.TJSDOC_ENV === 'development' ? '../tjsdoc-plugin-live-server/src/TJSDocLiveServer.js' :
       'tjsdoc-plugin-live-server';

      await eventbus.triggerAsync('plugins:add:async',
       { name: 'tjsdoc-plugin-live-server', target, options: liveServerOptions });
   }

   // Add a command to the tjsdoc-plugin-watcher to log all source documentation coverage
   eventbus.trigger('tjsdoc:system:watcher:command:add',
   {
      name: 'coverage-all',
      description: 'log all source documentation coverage',
      exec: ({ showPrompt } = {}) =>
      {
         eventbus.trigger('tjsdoc:data:docdb:coverage:source:log', { includeFiles: true, includeLines: true });
         showPrompt();
      }
   });

   // Add a command to the tjsdoc-plugin-watcher to open the default browser.
   eventbus.trigger('tjsdoc:system:watcher:command:add',
   {
      name: 'open',
      description: 'opens docs with default browser',
      exec: ({ showPrompt } = {}) =>
      {
         eventbus.trigger('typhonjs:util:live:server:open');
         showPrompt();
      }
   });

   // Add a command to the tjsdoc-plugin-watcher to turn incremental logging of source doc coverage on / off.
   eventbus.trigger('tjsdoc:system:watcher:command:add',
   {
      name: 'coverage',
      description: 'turns on / off logging incremental source documentation coverage',
      type: 'optional',
      state: typeof ev.pluginOptions.coverage === 'boolean' ? ev.pluginOptions.coverage : true
   });

   // Add a command to the tjsdoc-plugin-watcher to turn regeneration of dependent files on / off.
   eventbus.trigger('tjsdoc:system:watcher:command:add',
   {
      name: 'dependent',
      description: 'turns on / off regenerating dependent files',
      type: 'optional',
      state: typeof ev.pluginOptions.dependent === 'boolean' ? ev.pluginOptions.dependent : true
   });

   // Add a command to the tjsdoc-plugin-watcher to turn minimal incremental publishing on / off.
   eventbus.trigger('tjsdoc:system:watcher:command:add',
   {
      name: 'minimal',
      description: 'turns on / off minimal incremental publishing for fastest results',
      type: 'optional',
      state: typeof ev.pluginOptions.minimal === 'boolean' ? ev.pluginOptions.minimal : false
   });
}

/**
 * Handle any housekeeping when TJSDoc regenerates all docs.
 */
export function onRuntimeRegenerateAsync()
{
   if (docRegenerator)
   {
      docRegenerator.destroy();
      docRegenerator = void 0;
   }
}
